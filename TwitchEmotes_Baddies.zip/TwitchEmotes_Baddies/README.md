# Moosebrother Twitch Emotes - Submission guide (Yes, it's french)


1. Cloner le repository localement et créer une branche
1. Sauvegarder l'emote au format .TGA dans le répertoire /emotes. S'assurer qu'il soit 128x128 pixels
1. Éditer le fichier Emotes.lua pour y inclure la définition
    1. La section TwitchEmotes_Moosebrother_Emoticons définit le nom de l'emote dans le chat
    1. La section TwitchEmotes_Moosebrother_Emoticons_Pack définit le path du fichier TGA et le format de la chat.
        1. _Je n'ai pas testé d'autres formats que 28:28_
1. Commit la branche et soumettre le un Pull Request
