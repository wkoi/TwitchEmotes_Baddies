TwitchEmotes_Baddies_Emoticons = {
    ["Crungo"] = "Crungo",
    ["SputSussy"] = "SputSussy",

}

TwitchEmotes_Baddies_Emoticons_Pack = {
    ["Crungo"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\Crungo.tga:28:28",
    ["SputSussy"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\SputSussy.tga:112:112",

}

-- Register animation metadata for animated Moosebrother emotes.
-- Keep this in sync with the spritesheets generated under /emotes.
-- glue.tga was generated as a vertical strip of 64 frames, each 32x32, total image height 2048, 15 fps
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\SputSussy.tga", 6, 112, 112, 112, 672, 10)
