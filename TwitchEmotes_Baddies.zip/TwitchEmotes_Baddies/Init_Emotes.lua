local function addEmotePacks()
    Emoticons_RegisterPack("TwitchEmotes_Baddies", TwitchEmotes_Baddies_Emoticons, TwitchEmotes_Baddies_Emoticons_Pack)
end

addEmotePacks()
